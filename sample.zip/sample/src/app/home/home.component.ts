import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  title:string="My home page";
  name:string="Gopika";
  products: any[]=[
    {
    productid:1,
    productname:"Sony",
    productcode:"abc-123"
  },
  {
    productid:2,
    productname:"Lenovo",
    productcode:"def-456"
  },
  {
    productid:3,
    productname:"Dell",
    productcode:"ghi-789"
  }]

  constructor() { }

  ngOnInit() {
  }

}
